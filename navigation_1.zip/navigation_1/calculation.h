//Robot Direction
#ifndef _CALCULATION_H
#define _CALCULATION_H

#define STOP 0
#define FORWARD 1
#define BACKWARD 2
#define LEFTWARD 3
#define RIGHTWARD 4
#define ROTATE_CW 5 
#define ROTATE_C_CW 6
#define UPWARD_LEFT 7
#define UPWARD_RIGHT 8
#define DOWNWARD_LEFT 9
#define DOWNWARD_RIGHT 10


#define MOVING 1
#define STOPPING 0


#define CLOCKWISE 0
#define COUNTER_CLOCKWISE 1
#define HALT 2


void direction (int direction, int motor_direction[4]){

    if(direction == STOP)
    {
      motor_direction[0] = HALT;
      motor_direction[1] = HALT;
      motor_direction[2] = HALT;
      motor_direction[3] = HALT;

    }
}

void Analog_Stick_Calc ( float x, float y, float *magnitude, float *angle )
{
	const float pi = 3.141592653589793238;
	 //Serial.print("x now:");
	// Serial.println(x);
	// Serial.print("y now:");
	// Serial.println(y);
	if(fabs(x)<5) x = 0;
	if(fabs(y)<5) y = 0;

	*magnitude = std::sqrt(x*x + y*y); // calculate the magnitude using the Pythagorean theorem
  *angle = std::atan2(y, x) * 180 / pi; // calculate the angle using the arctangent function, and convert from radians to degrees
	return;
}


void calc_robot_dir ( float *magnitude , float *angle , int setpoint_m[4] , const int optimum_speed_m[4] , int motor_dir[4] , int dji_speed_increase, int motor[4]) {
    float ratio_speed_m[4];
    float ratio;

   Serial.print("magnitude now:");
	 Serial.println(*magnitude);
	 Serial.print("angle now:");
	 Serial.println(*angle);
	 delay(100);
	 
    for(int k = 0; k<4 ; k++){
      ledcWrite(motor[k],setpoint_m[k]);
    }

   if(*angle > 0 && *angle <= 30 || *angle>-30 && *angle <=0){
        //rightward 
        setpoint_m[0] = optimum_speed_m[0]+12+dji_speed_increase;
        setpoint_m[1] = optimum_speed_m[1]-12+dji_speed_increase;
        setpoint_m[2] = optimum_speed_m[2]-12+dji_speed_increase;
        setpoint_m[3] = optimum_speed_m[4]+12+dji_speed_increase;
        
   }

   else if(*angle>30 && *angle <=60)
	{
		//UPWARD_RIGHT;
		setpoint_m[0] = optimum_speed_m[0]+12+dji_speed_increase;
		setpoint_m[1] = optimum_speed_m[1];
		setpoint_m[2] = optimum_speed_m[2];
		setpoint_m[3] = optimum_speed_m[3]+12+dji_speed_increase;
  
	}

  else if(*angle>60 && *angle <=120)
  {
    //foward
    setpoint_m[0] = optimum_speed_m[0]+12+dji_speed_increase;
		setpoint_m[1] = optimum_speed_m[1]+12+dji_speed_increase;
		setpoint_m[2] = optimum_speed_m[2]+12+dji_speed_increase;
		setpoint_m[3] = optimum_speed_m[3]+12+dji_speed_increase;
  }
	
  else if(*angle>120 && *angle <=150)
	{
		//  UPWARD_LEFT;
		setpoint_m[0] = optimum_speed_m[0];
		setpoint_m[1] = optimum_speed_m[1]+12+dji_speed_increase;
		setpoint_m[2] = optimum_speed_m[2]+12+dji_speed_increase;
		setpoint_m[3] = optimum_speed_m[3];
	}

  else if(*angle>150 && *angle <=180 || *angle>-180 && *angle <=-150 )
  {
    // leftward
    setpoint_m[0] = optimum_speed_m[0]-12-dji_speed_increase;
		setpoint_m[1] = optimum_speed_m[1]+12+dji_speed_increase;
		setpoint_m[2] = optimum_speed_m[2]+12+dji_speed_increase;
		setpoint_m[3] = optimum_speed_m[3]-12-dji_speed_increase;
  }

  else if(*angle>-150 && *angle <=-120)
    {
      // lower left
      setpoint_m[0] = optimum_speed_m[0]-12-dji_speed_increase;
		  setpoint_m[1] = optimum_speed_m[1];
		  setpoint_m[2] = optimum_speed_m[2];
		  setpoint_m[3] = optimum_speed_m[3]-12-dji_speed_increase;
    }
  else if(*angle>-90 && *angle <=-60 || *angle>-120 && *angle <=-90 )
  {
    // backward
    setpoint_m[0] = optimum_speed_m[0]-12-dji_speed_increase;
		setpoint_m[1] = optimum_speed_m[1]-12-dji_speed_increase;
		setpoint_m[2] = optimum_speed_m[2]-12-dji_speed_increase;
		setpoint_m[3] = optimum_speed_m[3]-12-dji_speed_increase;
  }
  
  else if(*angle>-150 && *angle <=-120)
    {
      // lower right 
      setpoint_m[0] = optimum_speed_m[0];
		  setpoint_m[1] = optimum_speed_m[1]-12-dji_speed_increase;
		  setpoint_m[2] = optimum_speed_m[2]-12-dji_speed_increase;
		  setpoint_m[3] = optimum_speed_m[3];
    }

  
	/* for(int k = 0; k<4;k++)
	 {
		 ratio_speed_m[k] = optimum_speed_m[k] * magnitude_ratio;


	 }
*/
      






}
#endif